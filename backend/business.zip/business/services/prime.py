from __future__ import annotations

from decimal import Decimal
from typing import Any, Dict, Optional

from accounts.models import Wallet, CustomUser
from business.models import CommissionConfig, AutoPoolAccount
from .commission_policy import CommissionPolicy, ConfigurationError


def _q2(x) -> Decimal:
    return Decimal(str(x)).quantize(Decimal("0.01"))


def _credit_wallet(
    user: Optional[CustomUser],
    amount: Decimal,
    tx_type: str,
    meta: Dict[str, Any] | None = None,
    source_type: str = "",
    source_id: str = "",
) -> None:
    """
    Best-effort wallet credit. Payout decisioning must be handled by caller/policy.
    """
    if not user or _q2(amount) <= 0:
        return
    w = Wallet.get_or_create_for_user(user)
    w.credit(
        _q2(amount),
        tx_type=tx_type,
        meta=meta or {},
        source_type=source_type or "",
        source_id=str(source_id or ""),
    )


def _is_consumer(u: CustomUser) -> bool:
    try:
        role = str(getattr(u, "role", "")).strip().lower()
        category = str(getattr(u, "category", "")).strip().lower()
        return role == "user" or category == "consumer"
    except Exception:
        return False


def _load_products_block(cfg: CommissionConfig) -> Dict[str, Any]:
    """
    Return a 'products' block that supports both nested and flattened admin JSON:
      - Nested: {"products": {"150": {"base_amount": 150.00}, "750": {...}}}
      - Flattened: {"products.150.base_amount": 150.00, "products.750.base_amount": ...}
    Flattened keys are merged into the nested map for compatibility.
    """
    master = dict(getattr(cfg, "master_commission_json", {}) or {})
    products = dict(master.get("products", {}) or {})
    # Merge flattened keys like "products.150.base_amount"
    try:
        for k, v in list(master.items()):
            if isinstance(k, str) and k.startswith("products."):
                try:
                    _, rest = k.split("products.", 1)
                    parts = rest.split(".")
                    if not parts:
                        continue
                    pkey = parts[0]
                    node = products.setdefault(pkey, {})
                    if len(parts) == 1:
                        # e.g., "products.150": {...}
                        if isinstance(v, dict):
                            node.update(dict(v))
                    else:
                        # e.g., "products.150.base_amount": 150
                        node[parts[1]] = v
                except Exception:
                    continue
    except Exception:
        # best-effort
        pass
    return products


def _require_base_amount_for_150(cfg: CommissionConfig) -> Decimal:
    products = _load_products_block(cfg)
    row = dict(products.get("150", {}) or {})
    if "base_amount" not in row:
        raise ConfigurationError("Missing config path: products.150.base_amount")
    try:
        base = _q2(row.get("base_amount"))
    except Exception:
        raise ConfigurationError("Invalid decimal at products.150.base_amount")
    if base <= 0:
        raise ConfigurationError("products.150.base_amount must be > 0")
    return base


def _resolve_base_amount(cfg: CommissionConfig, product_key: str, multiplier: Optional[int] = None) -> Decimal:
    """
    Strict base_amount resolver for Agency (geo/upline) distribution:
      - 150: require products.150.base_amount (no defaults)
      - 750: prefer products.750.base_amount; if absent, compute products.150.base_amount * multiplier (strict)
    """
    products = _load_products_block(cfg)
    row = dict(products.get(product_key, {}) or {})

    if "base_amount" in row:
        try:
            v = _q2(row.get("base_amount"))
        except Exception:
            raise ConfigurationError(f"Invalid decimal at products.{product_key}.base_amount")
        if v <= 0:
            raise ConfigurationError(f"products.{product_key}.base_amount must be > 0")
        return v

    if product_key == "750":
        if not isinstance(multiplier, int) or multiplier <= 0:
            raise ConfigurationError("prime_750.multiplier must be a positive integer to derive products.750.base_amount")
        base150 = _require_base_amount_for_150(cfg)
        return _q2(base150 * Decimal(multiplier))

    # fallback for any other product key: require explicit
    raise ConfigurationError(f"Missing config path: products.{product_key}.base_amount")


def distribute_prime_150_payouts(
    consumer: CustomUser,
    *,
    source: Dict[str, Any],
) -> None:
    """
    BRAND-NEW payout engine for Prime 150 activation (package or coupon).
    Enforces Global Rules:
      1) No hardcoded rupee values
      2) Read strictly from AdminCommissionDistribute config (master_commission_json)
      3) If config missing/invalid -> ConfigurationError (stop payout)
      4) Same engine semantics across package/coupon
      5) Readable/auditable code
    Effects:
      - DIRECT_REF bonus to sponsor (PRIME_150_DIRECT)
      - SELF bonus to consumer (PRIME_150_SELF)
      - Agency distribution via distribute_auto_pool_commissions with base_amount=products.150.base_amount
      - Matrix opening (5/3) when enabled in policy
      - Reward points credit (PRIME_150)
    """
    if not consumer:
        return

    policy = CommissionPolicy.load()
    p150 = policy.prime150()  # strict validation

    sponsor = getattr(consumer, "registered_by", None)
    src_type = str(source.get("type") or "PRIME_150")
    src_id = str(source.get("id") or "")

    # 1) Direct + Self (strict decimals)
    direct_amt = _q2(p150.direct_sponsor)
    if sponsor and direct_amt > 0:
        _credit_wallet(
            sponsor,
            direct_amt,
            tx_type="PRIME_150_DIRECT",
            meta={"source": "PRIME_150"},
            source_type=src_type,
            source_id=src_id,
        )

    self_amt = _q2(p150.direct_self)
    if self_amt > 0:
        _credit_wallet(
            consumer,
            self_amt,
            tx_type="PRIME_150_SELF",
            meta={"source": "PRIME_150"},
            source_type=src_type,
            source_id=src_id,
        )

    # 2) Agency distribution (best-effort base_amount)
    cfg = CommissionConfig.get_solo()
    base150: Optional[Decimal] = None
    try:
        v = _resolve_base_amount(cfg, "150", None)
        if v > 0:
            base150 = v
    except Exception:
        base150 = None

    if base150 is not None:
        from business.models import distribute_auto_pool_commissions  # local import to avoid circular
        distribute_auto_pool_commissions(
            consumer,
            base_amount=_q2(base150),
            fixed_key="150",
            source_type=src_type,
            source_id=src_id,
            extra_meta={"trigger": "PRIME_150"},
        )

    # 3) Matrix opening (config-driven; no rupee defaults)
    # Open N accounts per matrix equal to coupon_activation_count
    count = int(p150.coupon_activation_count)
    if count < 0:
        raise ConfigurationError("commissions.prime_150.coupons.activation_count must be >= 0")
    if _is_consumer(consumer) and count > 0 and base150 is not None:
        # 5-matrix
        if bool(p150.enable_5_matrix):
            for _ in range(count):
                try:
                    AutoPoolAccount.create_five_150_for_user(
                        consumer,
                        amount=_q2(base150),
                        source_type=src_type,
                        source_id=src_id,
                    )
                except Exception:
                    # best-effort placement; do not stop payout credits
                    pass
        # 3-matrix (150)
        if bool(p150.enable_3_matrix):
            for _ in range(count):
                try:
                    AutoPoolAccount.create_three_150_for_user(
                        consumer,
                        amount=_q2(base150),
                        source_type=src_type or "SYSTEM",
                        source_id=src_id or "",
                    )
                except Exception:
                    pass

    # 4) Reward points (optional, config-driven)
    try:
        from accounts.models import RewardPointsAccount
        pts = _q2(p150.reward_points_amount)
        if pts > 0:
            RewardPointsAccount.credit_points(
                consumer,
                pts,
                reason="PRIME_150",
                meta={"source_type": src_type, "source_id": src_id},
            )
    except Exception:
        # Best-effort; do not block other credits
        pass


def distribute_prime_750_payouts(
    consumer: CustomUser,
    *,
    source: Dict[str, Any],
) -> None:
    """
    Prime 750 payout engine driven by Admin master_commission_json (per-product '750' keys).
    Effects:
      - DIRECT_REF and SELF bonuses from master.direct_bonus['750']
      - Agency distribution base from master.products['750'].base_amount
      - Matrix openings count from master.products['750'].activation_open_count (optional)
      - No coupling to Prime 150 multiplier
    """
    if not consumer:
        return

    sponsor = getattr(consumer, "registered_by", None)
    src_type = str(source.get("type") or "PRIME_750")
    src_id = str(source.get("id") or "")

    # Load master commission config once
    cfg = CommissionConfig.get_solo()
    master = dict(getattr(cfg, "master_commission_json", {}) or {})

    # 1) Direct + Self from per-product 750 config
    try:
        direct_all = dict(master.get("direct_bonus", {}) or {})
    except Exception:
        direct_all = {}
    row750 = dict(direct_all.get("750", {}) or {})
    if not row750:
        for alias in ("rs750", "prime750", "prime_750"):
            try:
                cand = direct_all.get(alias)
                if isinstance(cand, dict) and cand:
                    row750 = dict(cand)
                    break
            except Exception:
                continue
    pay_direct = _q2(row750.get("sponsor", 0))
    pay_self = _q2(row750.get("self", 0))

    if sponsor and pay_direct > 0:
        _credit_wallet(
            sponsor,
            pay_direct,
            tx_type="PRIME_750_DIRECT",
            meta={"source": "PRIME_750"},
            source_type=src_type,
            source_id=src_id,
        )

    if pay_self > 0:
        _credit_wallet(
            consumer,
            pay_self,
            tx_type="PRIME_750_SELF",
            meta={"source": "PRIME_750"},
            source_type=src_type,
            source_id=src_id,
        )

    # 2) Agency distribution using products['750'].base_amount (with aliases and multiplier fallback)
    base750: Optional[Decimal] = None
    try:
        # Prefer strict resolver: products.750.base_amount, else derive via prime_750.multiplier × products.150.base_amount
        cfg2 = CommissionConfig.get_solo()
        try:
            pol = CommissionPolicy.load()
            mult = pol.prime750().multiplier
        except Exception:
            mult = None
        base750 = _resolve_base_amount(cfg2, "750", multiplier=mult)
    except Exception:
        # Fallback: accept aliases under products.rs750/prime750/prime_750
        try:
            products = dict(master.get("products", {}) or {})
            p750 = (
                dict(products.get("750", {}) or {})
                or dict(products.get("rs750", {}) or {})
                or dict(products.get("prime750", {}) or {})
                or dict(products.get("prime_750", {}) or {})
            )
            bv = _q2(p750.get("base_amount"))
            if bv > 0:
                base750 = bv
            else:
                base750 = None
        except Exception:
            base750 = None

    if base750 is not None:
        from business.models import distribute_auto_pool_commissions
        distribute_auto_pool_commissions(
            consumer,
            base_amount=_q2(base750),
            fixed_key="750",
            source_type=src_type,
            source_id=src_id,
            extra_meta={"trigger": "PRIME_750"},
        )

    # 3) Matrix opening count from per-product (optional). If absent/invalid -> 0.
    count = 0
    try:
        products = dict(master.get("products", {}) or {})
        p750 = (
            dict(products.get("750", {}) or {})
            or dict(products.get("rs750", {}) or {})
            or dict(products.get("prime750", {}) or {})
            or dict(products.get("prime_750", {}) or {})
        )
        aoc = p750.get("activation_open_count", None)
        if aoc is None:
            # also allow top-level map activation_open_count.{key}=N if UI stores it there
            aoc_map = dict(master.get("activation_open_count", {}) or {})
            aoc = (
                aoc_map.get("750", None)
                or aoc_map.get("rs750", None)
                or aoc_map.get("prime750", None)
                or aoc_map.get("prime_750", None)
            )
        count = int(aoc) if aoc is not None else 0
    except Exception:
        count = 0
    if count < 0:
        count = 0

    # Matrix enable flags for 750 based on per-product overrides (do NOT reuse 150 flags)
    try:
        master_for_enable = dict(getattr(cfg, "master_commission_json", {}) or {})
        enable_5 = CommissionPolicy._enabled_from_cm(master_for_enable, "consumer_matrix_5", "750")
        enable_3 = CommissionPolicy._enabled_from_cm(master_for_enable, "consumer_matrix_3", "750")
    except Exception:
        enable_5 = False
        enable_3 = False

    if _is_consumer(consumer) and count > 0 and base750 is not None:
        if enable_5:
            for _ in range(count):
                try:
                    AutoPoolAccount.create_five_150_for_user(
                        consumer,
                        amount=_q2(base750),
                        source_type=src_type,
                        source_id=src_id,
                    )
                except Exception:
                    pass
        if enable_3:
            for _ in range(count):
                try:
                    AutoPoolAccount.create_three_150_for_user(
                        consumer,
                        amount=_q2(base750),
                        source_type=src_type or "SYSTEM",
                        source_id=src_id or "",
                    )
                except Exception:
                    pass

    # 4) Reward points: handled by activation flow; no separate points logic here to avoid unintended coupling
    return

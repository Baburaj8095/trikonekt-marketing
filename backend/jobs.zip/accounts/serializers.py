from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from django.db import transaction
from django.db.models import Q, Case, When, Value, IntegerField
import os

from core.crypto import encrypt_string

from .models import CustomUser, AgencyRegionAssignment, WalletTransaction, Wallet, UserKYC, WithdrawalRequest, SupportTicket, SupportTicketMessage, UserNominee
from locations.models import Country, State, City



AGENCY_CATEGORIES = {
    'agency_state_coordinator',
    'agency_state',
    'agency_district_coordinator',
    'agency_district',
    'agency_pincode_coordinator',
    'agency_pincode',
    'agency_sub_franchise',
}

# Assignment caps per spec
MAX_STATES_PER_SC = 2           # State Coordinator can select max 2 states
MAX_DISTRICTS_PER_DC = 4        # District Coordinator can manage max 4 districts
MAX_PINCODES_PER_PC = 4         # Pincode Coordinator can manage up to 4 pincodes


class RegisterSerializer(serializers.ModelSerializer):
    # Inputs
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    full_name = serializers.CharField(required=False, allow_blank=True)
    phone = serializers.CharField(required=False, allow_blank=True)
    country = serializers.PrimaryKeyRelatedField(queryset=Country.objects.all(), required=False, allow_null=True)
    state = serializers.PrimaryKeyRelatedField(queryset=State.objects.all(), required=False, allow_null=True)
    city = serializers.PrimaryKeyRelatedField(queryset=City.objects.all(), required=False, allow_null=True)
    pincode = serializers.CharField(required=False, allow_blank=True)
    sponsor_id = serializers.CharField(required=True, allow_blank=False)
    category = serializers.ChoiceField(choices=[(code, code) for code, _ in CustomUser.CATEGORY_CHOICES], required=False, default='consumer')

    # Region assignment inputs (write-only)
    # For agency_state_coordinator
    assign_states = serializers.ListField(child=serializers.IntegerField(), required=False, write_only=True)

    # For agency_state and deeper levels
    selected_state = serializers.PrimaryKeyRelatedField(queryset=State.objects.all(), required=False, allow_null=True, write_only=True)

    # For agency_district_coordinator
    assign_districts = serializers.ListField(child=serializers.CharField(allow_blank=False), required=False, write_only=True)

    # For agency_district and deeper levels
    selected_district = serializers.CharField(required=False, allow_blank=True, write_only=True)

    # For agency_pincode_coordinator
    assign_pincodes = serializers.ListField(child=serializers.RegexField(r'^\d{6}$'), required=False, write_only=True)

    # For agency_pincode and agency_sub_franchise
    selected_pincode = serializers.RegexField(r'^\d{6}$', required=False, allow_blank=True, write_only=True)

    # Optional write-only helpers to resolve FK by names/codes coming from Geoapify
    country_name = serializers.CharField(required=False, allow_blank=True, write_only=True)
    country_code = serializers.CharField(required=False, allow_blank=True, write_only=True)  # iso2 like IN
    state_name = serializers.CharField(required=False, allow_blank=True, write_only=True)
    state_code = serializers.CharField(required=False, allow_blank=True, write_only=True)    # e.g. KA (may be unused)
    city_name = serializers.CharField(required=False, allow_blank=True, write_only=True)

    # Outputs
    username = serializers.CharField(read_only=True)
    unique_id = serializers.CharField(read_only=True)

    class Meta:
        model = CustomUser
        fields = (
            'id', 'username', 'unique_id', 'prefixed_id', 'prefix_code', 'email', 'password', 'role', 'category',
            'full_name', 'phone',
            'country', 'state', 'city', 'pincode', 'sponsor_id',
            # region assignment inputs
            'assign_states', 'selected_state', 'assign_districts', 'selected_district',
            'assign_pincodes', 'selected_pincode',
            # helper write-only inputs
            'country_name', 'country_code', 'state_name', 'state_code', 'city_name'
        )
        extra_kwargs = {
            'role': {'required': False},
        }

    def to_internal_value(self, data):
        """
        Make geo inputs tolerant:
        - Accept PK integers, digit strings, dicts like {id: ...}, or plain names/codes.
        - If a plain name is provided for country/state/city in the PK field, move it to
          the corresponding *_name helper and drop the PK field so DRF doesn't reject it.
        - Accept aliases: country_id/state_id/city_id and camelCase variants.
        - Normalize pincode (digits only) and allow dicts with value/pincode.
        """
        d = (data or {}).copy()

        def _extract_id(val):
            if isinstance(val, dict):
                for k in ("id", "value", "pk"):
                    if k in val and val[k] is not None:
                        return val[k]
            return val

        # Alias mapping (snake and camel)
        alias_pairs = [
            ("country", "country_id"), ("state", "state_id"), ("city", "city_id"),
            ("country", "countryId"), ("state", "stateId"), ("city", "cityId"),
        ]
        for field, alias in alias_pairs:
            if d.get(alias) is not None and d.get(field) is None:
                d[field] = d.get(alias)

        # Normalize PK-or-name values for country/state/city
        for field in ("country", "state", "city"):
            if field not in d:
                continue
            raw = _extract_id(d.get(field))
            # If it's already an int, keep it
            if isinstance(raw, int):
                d[field] = raw
                continue
            # Digit string -> int
            if isinstance(raw, str):
                sval = raw.strip()
                if sval.isdigit():
                    d[field] = int(sval)
                    continue
                # Non-digit string: treat as name/code and move to helper
                if field == "country":
                    # Two/three-letter code treated as iso2/iso3 best-effort
                    if 1 <= len(sval) <= 3 and sval.isalpha():
                        d["country_code"] = sval
                    else:
                        d["country_name"] = sval
                elif field == "state":
                    d["state_name"] = sval
                else:
                    d["city_name"] = sval
                d.pop(field, None)
                continue
            # Other types -> stringify and retry
            sval = str(raw).strip()
            if sval.isdigit():
                d[field] = int(sval)
            else:
                if field == "country":
                    if 1 <= len(sval) <= 3 and sval.isalpha():
                        d["country_code"] = sval
                    else:
                        d["country_name"] = sval
                elif field == "state":
                    d["state_name"] = sval
                else:
                    d["city_name"] = sval
                d.pop(field, None)

        # selected_state: accept dict/id/digit string
        if "selected_state" in d:
            ss = _extract_id(d.get("selected_state"))
            if isinstance(ss, str) and ss.strip().isdigit():
                d["selected_state"] = int(ss.strip())
            elif isinstance(ss, int):
                d["selected_state"] = ss
            else:
                # If a name was placed here by mistake, move to helper and drop PK
                try:
                    ssv = str(ss).strip()
                    if ssv and not ssv.isdigit():
                        d["state_name"] = d.get("state_name") or ssv
                        d.pop("selected_state", None)
                except Exception:
                    d.pop("selected_state", None)

        # Normalize pincode (allow dicts and strip non-digits)
        if "pincode" in d:
            pin_raw = d.get("pincode")
            if isinstance(pin_raw, dict):
                pin_raw = pin_raw.get("value") or pin_raw.get("pincode") or pin_raw.get("PIN") or pin_raw.get("pin") or ""
            pin_str = "".join(c for c in str(pin_raw or "").strip() if c.isdigit())
            if pin_str:
                d["pincode"] = pin_str

        return super().to_internal_value(d)

    def validate(self, attrs):
        category = attrs.get('category', 'consumer') or 'consumer'
        phone = (attrs.get('phone') or '').strip()
        sponsor = (attrs.get('sponsor_id') or '').strip()

        # Phone required for all registrations; allow same phone for multiple accounts (different prefixes)
        if not phone:
            raise serializers.ValidationError({'phone': 'Phone number is required.'})
        phone_digits = ''.join(c for c in phone if c.isdigit())
        if not phone_digits or len(phone_digits) != 10:
            raise serializers.ValidationError({'phone': 'Enter a valid 10-digit phone number.'})


        # Sponsor required: accept username, prefixed_id (with/without dash), phone digits, or unique_id
        if not sponsor:
            raise serializers.ValidationError({'sponsor_id': 'Sponsor ID is required.'})

        raw = sponsor.strip()
        # Resolve sponsor deterministically:
        # 1) Try exact identifiers (prefixed_id with/without dash, username, unique_id)
        # 2) Fallback to phone/possible numeric-username and prefer non-consumer agency accounts
        t_no_dash = ''.join(ch for ch in raw if ch.isalnum())
        # Derive category hint from known username prefixes (e.g., TRSF -> agency_sub_franchise)
        try:
            prefix = (raw[:4] or '').upper()
        except Exception:
            prefix = ''
        category_by_prefix = {
            'TRSF': 'agency_sub_franchise',
            'TRPN': 'agency_pincode',
            'TRST': 'agency_state',
            'TRDT': 'agency_district',
            'TREP': 'employee',
            'TRBS': 'business',
            'TRSC': 'agency_state_coordinator',
            'TRDC': 'agency_district_coordinator',
            'TRPC': 'agency_pincode_coordinator',
        }
        cat_hint = category_by_prefix.get(prefix)
        sponsor_user = None

        # 1) prefixed_id exact (with dash)
        sponsor_user = CustomUser.objects.filter(prefixed_id__iexact=raw).first()
        # 1a) prefixed_id exact (dashless)
        if not sponsor_user and t_no_dash and t_no_dash != raw:
            sponsor_user = CustomUser.objects.filter(prefixed_id__iexact=t_no_dash).first()

        # 2) username exact (TRSF##########, coordinators numeric usernames, etc.)
        if not sponsor_user:
            # Prefer exact username match within hinted category first
            if cat_hint:
                sponsor_user = CustomUser.objects.filter(username__iexact=raw, category=cat_hint).first()
            if not sponsor_user:
                sponsor_user = CustomUser.objects.filter(username__iexact=raw).first()
                # If matched username is not of the hinted category, discard and continue searching
                if sponsor_user and cat_hint and getattr(sponsor_user, 'category', '') != cat_hint:
                    sponsor_user = None

        # 3) unique_id exact (6-digit)
        if not sponsor_user:
            sponsor_user = CustomUser.objects.filter(unique_id__iexact=raw).first()

        # 3a) If we have a category hint from the username prefix, resolve by category+phone
        if not sponsor_user and cat_hint:
            digits = ''.join(ch for ch in raw if ch.isdigit())
            if digits:
                sponsor_user = (
                    CustomUser.objects
                    .filter(category=cat_hint)
                    .filter(Q(phone__iexact=digits) | Q(username__iexact=raw))
                    .order_by('-id')
                    .first()
                )

        # 3b) If category hint and digits exist, try username ending with the digits within the hinted category
        #     This supports sponsor codes like TRSF<phone> even if the exact username lookup failed.
        if not sponsor_user and cat_hint:
            digits2 = ''.join(ch for ch in raw if ch.isdigit())
            if digits2:
                sponsor_user = (
                    CustomUser.objects
                    .filter(category=cat_hint, username__iendswith=digits2)
                    .order_by('-id')
                    .first()
                )

        # 4) fallback by phone digits or numeric username; prefer agency over consumer; if a category hint exists, restrict to it
        if not sponsor_user:
            digits = ''.join(ch for ch in raw if ch.isdigit())
            if digits:
                base_qs = CustomUser.objects.filter(Q(phone__iexact=digits) | Q(username__iexact=digits))
                if cat_hint:
                    base_qs = base_qs.filter(category=cat_hint)
                if base_qs.exists():
                    qs = base_qs.annotate(
                        rank=Case(
                            When(category='agency_sub_franchise', then=Value(0)),
                            When(category__in=list(AGENCY_CATEGORIES - {'agency_sub_franchise'}), then=Value(1)),
                            When(category='employee', then=Value(2)),
                            When(category='consumer', then=Value(9)),
                            default=Value(5),
                            output_field=IntegerField(),
                        )
                    ).order_by('rank', '-id')
                    sponsor_user = qs.first()

        if not sponsor_user:
            # Final attempt: if a category hint exists from the username prefix (e.g., TRSF...),
            # try to locate a sponsor strictly within that category using phone or exact username.
            if cat_hint:
                digits2 = ''.join(ch for ch in raw if ch.isdigit())
                alt = None
                if digits2:
                    alt = (
                        CustomUser.objects
                        .filter(category=cat_hint, phone__iexact=digits2)
                        .order_by('-id')
                        .first()
                    )
                if not alt:
                    alt = CustomUser.objects.filter(category=cat_hint, username__iexact=raw).first()
                if alt:
                    sponsor_user = alt

        # If resolved sponsor does not match hinted category (e.g., resolved to consumer while TRSF was provided),
        # prefer an alternate match within the hinted category by phone/username suffix.
        if sponsor_user and cat_hint and getattr(sponsor_user, 'category', '') != cat_hint:
            digits3 = ''.join(ch for ch in raw if ch.isdigit())
            alt2 = (
                CustomUser.objects
                .filter(category=cat_hint)
                .filter(Q(username__iexact=raw) | Q(phone__iexact=digits3) | Q(username__iendswith=digits3))
                .order_by('-id')
                .first()
            )
            if alt2:
                sponsor_user = alt2

        if not sponsor_user:
            raise serializers.ValidationError({'sponsor_id': 'Sponsor not found. Use username/prefixed code/phone.'})

        # Enforce agency hierarchy transitions only for agency categories
        if category in AGENCY_CATEGORIES:
            # Admin/company/root-consumer can sponsor any agency category (including sub-franchise)
            is_root_consumer = False
            try:
                from business.models import RootConsumerConfig
                rc_user = RootConsumerConfig.get_solo().get_root_user()
                is_root_consumer = bool(rc_user and rc_user.id == getattr(sponsor_user, 'id', None))
            except Exception:
                is_root_consumer = False
            admin_relaxed = (
                getattr(sponsor_user, 'is_superuser', False)
                or getattr(sponsor_user, 'is_staff', False)
                or getattr(sponsor_user, 'category', '') == 'company'
                or is_root_consumer
            )
            if admin_relaxed:
                allowed_next = AGENCY_CATEGORIES
                sponsor_cat = 'admin'
            else:
                allowed = {
                    'agency_state_coordinator': {'agency_state'},
                    'agency_state': {'agency_district_coordinator'},
                    'agency_district_coordinator': {'agency_district'},
                    'agency_district': {'agency_pincode_coordinator'},
                    'agency_pincode_coordinator': {'agency_pincode'},
                    'agency_pincode': {'agency_sub_franchise'},
                    'agency_sub_franchise': {'agency_sub_franchise'},
                }
                # Use effective sponsor category derived from the provided sponsor code prefix if available
                # (e.g., TRSF -> agency_sub_franchise), else fall back to DB category.
                sponsor_cat = (cat_hint if cat_hint in AGENCY_CATEGORIES else (getattr(sponsor_user, 'category', '') or ''))
                allowed_next = allowed.get(sponsor_cat, set())

            if category not in allowed_next:
                raise serializers.ValidationError({
                    'category': f'Invalid category for sponsor. Sponsor category "{sponsor_cat}" can sponsor only {sorted(list(allowed_next))}.'
                })

            # Recompute here for clarity in region checks (same logic as above)
            is_root_consumer = False
            try:
                from business.models import RootConsumerConfig
                rc_user = RootConsumerConfig.get_solo().get_root_user()
                is_root_consumer = bool(rc_user and rc_user.id == getattr(sponsor_user, 'id', None))
            except Exception:
                is_root_consumer = False
            admin_relaxed = (
                getattr(sponsor_user, 'is_superuser', False)
                or getattr(sponsor_user, 'is_staff', False)
                or getattr(sponsor_user, 'category', '') == 'company'
                or is_root_consumer
            )
            # Region-level validations by category
            # Store resolved values for use in create()
            self._assign_states = []
            self._assign_districts = []
            self._assign_pincodes = []
            self._selected_state = None
            self._selected_district = None
            self._selected_pincode = None

            if category == 'agency_state_coordinator' and not admin_relaxed:
                ids = attrs.get('assign_states') or []
                if not ids:
                    raise serializers.ValidationError({'assign_states': 'At least one state must be selected.'})
                if len(ids) > MAX_STATES_PER_SC:
                    raise serializers.ValidationError({'assign_states': f'Maximum {MAX_STATES_PER_SC} states allowed.'})
                # Admin sponsor has no assignments; allow any states
                states_qs = State.objects.filter(id__in=ids)
                if states_qs.count() != len(set(ids)):
                    raise serializers.ValidationError({'assign_states': 'One or more selected states are invalid.'})
                self._assign_states = list(states_qs)

            elif category == 'agency_state_coordinator' and admin_relaxed:
                ids = attrs.get('assign_states') or []
                # Optional: accept any provided here; caps enforced in admin distribution.
                states_qs = State.objects.filter(id__in=ids) if ids else State.objects.none()
                self._assign_states = list(states_qs)
            elif category == 'agency_state' and not admin_relaxed:
                sel_state = attrs.get('selected_state')
                if not sel_state:
                    raise serializers.ValidationError({'selected_state': 'State selection is required.'})
                # Validate that sponsor has this state assignment (unless sponsor is admin, which can't sponsor this category anyway)
                ok = AgencyRegionAssignment.objects.filter(user=sponsor_user, level='state', state=sel_state).exists()
                if not ok:
                    raise serializers.ValidationError({'selected_state': 'Selected state is not under the sponsor\'s assignment.'})
                self._selected_state = sel_state

            elif category == 'agency_state' and admin_relaxed:
                sel_state = attrs.get('selected_state')
                self._selected_state = sel_state if sel_state else None
            elif category == 'agency_district_coordinator':
                sel_state = attrs.get('selected_state')
                if not sel_state:
                    raise serializers.ValidationError({'selected_state': 'State selection is required.'})
                ok = AgencyRegionAssignment.objects.filter(user=sponsor_user, level='state', state=sel_state).exists()
                if not ok:
                    raise serializers.ValidationError({'selected_state': 'Selected state is not under the sponsor\'s assignment.'})
                districts = [d.strip() for d in (attrs.get('assign_districts') or []) if d and str(d).strip()]
                if not districts:
                    raise serializers.ValidationError({'assign_districts': 'At least one district must be provided.'})
                if len(districts) > MAX_DISTRICTS_PER_DC:
                    raise serializers.ValidationError({'assign_districts': f'Maximum {MAX_DISTRICTS_PER_DC} districts allowed.'})
                self._selected_state = sel_state
                # de-dup case-insensitively but preserve order
                seen = set()
                normed = []
                for d in districts:
                    key = d.lower()
                    if key not in seen:
                        seen.add(key)
                        normed.append(d)
                self._assign_districts = normed

            elif category == 'agency_district':
                sel_state = attrs.get('selected_state')
                sel_district = (attrs.get('selected_district') or '').strip()
                if not sel_state:
                    raise serializers.ValidationError({'selected_state': 'State selection is required.'})
                if not sel_district:
                    raise serializers.ValidationError({'selected_district': 'District selection is required.'})
                ok = AgencyRegionAssignment.objects.filter(
                    user=sponsor_user, level='district', state=sel_state, district__iexact=sel_district
                ).exists()
                if not ok:
                    raise serializers.ValidationError({'selected_district': 'Selected district is not under the sponsor\'s assignment.'})
                self._selected_state = sel_state
                self._selected_district = sel_district

            elif category == 'agency_pincode_coordinator':
                sel_state = attrs.get('selected_state')
                sel_district = (attrs.get('selected_district') or '').strip()
                if not sel_state:
                    raise serializers.ValidationError({'selected_state': 'State selection is required.'})
                if not sel_district:
                    raise serializers.ValidationError({'selected_district': 'District selection is required.'})
                ok = AgencyRegionAssignment.objects.filter(
                    user=sponsor_user, level='district', state=sel_state, district__iexact=sel_district
                ).exists()
                if not ok:
                    raise serializers.ValidationError({'selected_district': 'Selected district is not under the sponsor\'s assignment.'})
                pins = [p for p in (attrs.get('assign_pincodes') or []) if p]
                if not pins:
                    raise serializers.ValidationError({'assign_pincodes': 'At least one pincode must be provided.'})
                if len(pins) > MAX_PINCODES_PER_PC:
                    raise serializers.ValidationError({'assign_pincodes': f'Maximum {MAX_PINCODES_PER_PC} pincodes allowed.'})
                # de-dup preserve order
                seenp = set()
                Pins = []
                for p in pins:
                    if p not in seenp:
                        seenp.add(p)
                        Pins.append(p)
                self._selected_state = sel_state
                self._selected_district = sel_district
                self._assign_pincodes = Pins

            elif category == 'agency_pincode':
                sel_pin = (attrs.get('selected_pincode') or '').strip()
                if not sel_pin:
                    raise serializers.ValidationError({'selected_pincode': 'Pincode selection is required.'})
                ok = AgencyRegionAssignment.objects.filter(
                    user=sponsor_user, level='pincode', pincode=sel_pin
                ).exists()
                if not ok:
                    raise serializers.ValidationError({'selected_pincode': 'Selected pincode is not under the sponsor\'s assignment.'})
                self._selected_pincode = sel_pin
                # Optional: capture selected state/district if provided to populate profile fields
                try:
                    self._selected_state = attrs.get('selected_state') or None
                except Exception:
                    self._selected_state = None
                try:
                    sd = (attrs.get('selected_district') or '').strip()
                    self._selected_district = sd or None
                except Exception:
                    self._selected_district = None

            elif category == 'agency_sub_franchise':
                sel_pin = (attrs.get('selected_pincode') or '').strip()
                if not sel_pin:
                    raise serializers.ValidationError({'selected_pincode': 'Pincode selection is required.'})
                # Allow any valid 6-digit pincode for sub-franchise; no sponsor assignment restriction
                self._selected_pincode = sel_pin
                # Optionally capture selected state/district if UI provided, so profile can reflect geo immediately
                try:
                    self._selected_state = attrs.get('selected_state') or None
                except Exception:
                    self._selected_state = None
                try:
                    sd = (attrs.get('selected_district') or '').strip()
                    self._selected_district = sd or None
                except Exception:
                    self._selected_district = None

        # Keep a reference for use in create()
        self._sponsor_user = sponsor_user

        # Require explicit geo selection for Consumer and Employee
        if category in ('consumer', 'employee'):
            pin_val = (attrs.get('pincode') or '').strip()
            if not pin_val or not pin_val.isdigit() or len(pin_val) != 6:
                raise serializers.ValidationError({'pincode': '6-digit pincode is required.'})
            if not attrs.get('country'):
                raise serializers.ValidationError({'country': 'Country selection is required.'})
            if not attrs.get('state'):
                raise serializers.ValidationError({'state': 'State selection is required.'})
            if not attrs.get('city'):
                raise serializers.ValidationError({'city': 'District selection is required.'})

        # Enforce per-role username uniqueness (and special consumer rule)
        try:
            phone_digits = ''.join(c for c in (phone or '') if c.isdigit())
        except Exception:
            phone_digits = (phone or '')
        username_base = self._build_username(category, phone_digits, '')
        # USERNAME_FIELD is globally unique; enforce against username only.
        if CustomUser.objects.filter(username__iexact=username_base).exists():
            if category == 'consumer':
                # Deterministic phone-only username => same phone implies same username for consumer
                raise serializers.ValidationError({'phone': 'Consumer already exists for this phone number.'})
            # For non-consumer categories, we'll auto-generate a unique username with suffix during create().

        # Basic email validation presence is optional; rely on DRF internal if provided
        return attrs

    def _resolve_locations(self, validated_data):
        country = validated_data.pop('country', None)
        state = validated_data.pop('state', None)
        city = validated_data.pop('city', None)
        # helper write-only values from Geoapify
        country_name = (validated_data.pop('country_name', '') or '').strip()
        country_code = (validated_data.pop('country_code', '') or '').strip()
        state_name = (validated_data.pop('state_name', '') or '').strip()
        state_code = (validated_data.pop('state_code', '') or '').strip()
        city_name = (validated_data.pop('city_name', '') or '').strip()

        # Best-effort resolve by code/name when PKs weren't provided
        if country is None and (country_code or country_name):
            country_qs = Country.objects.all()
            if country_code:
                c = country_qs.filter(iso2__iexact=country_code).first()
                if c:
                    country = c
            if country is None and country_name:
                c = country_qs.filter(name__iexact=country_name).first()
                if c:
                    country = c

        if state is None and state_name and country is not None:
            s = State.objects.filter(country=country, name__iexact=state_name).first()
            if s is None:
                s = State.objects.filter(country=country, name__icontains=state_name).first()
            if s:
                state = s

        if city is None and city_name and state is not None:
            ci = City.objects.filter(state=state, name__iexact=city_name).first()
            if ci is None:
                ci = City.objects.filter(state=state, name__icontains=city_name).first()
            if ci:
                city = ci

        return country, state, city

    def _derive_role(self, category: str) -> str:
        if category in AGENCY_CATEGORIES:
            return 'agency'
        if category == 'employee':
            return 'employee'
        # consumer and business default to basic user
        return 'user'

    def _build_username(self, category: str, phone: str, unique_id: str) -> str:
        """
        Generate admin-friendly usernames using prefixes by category.
        - Consumer: phone (digits-only)
        - Employee: TREP+phone
        - Merchant: TRBS+phone
        - Business: TRBS+phone
        - Agency:
            - State Coordinator: TRSC+phone
            - District Coordinator: TRDC+phone
            - Pincode Coordinator: TRPC+phone
            - State: TRST+phone
            - District: TRDT+phone
            - Pincode: TRPN+phone
            - Sub-Franchise: TRSF+phone
        """
        phone_digits = ''.join(c for c in (phone or '') if c.isdigit())

        prefix_map = {
            'employee': 'TREP',
            'merchant': 'TRBS',
            'business': 'TRBS',
            'agency_state_coordinator': 'TRSC',
            'agency_district_coordinator': 'TRDC',
            'agency_pincode_coordinator': 'TRPC',
            'agency_state': 'TRST',
            'agency_district': 'TRDT',
            'agency_pincode': 'TRPN',
            'agency_sub_franchise': 'TRSF',
        }

        if category == 'consumer':
            base = phone_digits
        else:
            pref = prefix_map.get(category, 'TR')
            base = f"{pref}{phone_digits}"

        username = base
        return username

    def _build_unique_username(self, category: str, phone: str, unique_id: str) -> str:
        """
        Ensure a globally-unique username. Uses category-specific base from _build_username,
        if taken appends -2, -3, ... until free.
        """
        base = self._build_username(category, phone, unique_id)
        uname = base
        i = 2
        while CustomUser.objects.filter(username__iexact=uname).exists():
            uname = f"{base}-{i}"
            i += 1
        return uname

    @transaction.atomic
    def create(self, validated_data):
        request = self.context.get('request')
        # resolve FKs (may be overridden by selected values for agency categories)
        country, state, city = self._resolve_locations(validated_data)

        full_name = validated_data.pop('full_name', '')
        phone = (validated_data.pop('phone', '') or '').strip()
        phone_digits = ''.join(c for c in phone if c.isdigit())
        pincode = validated_data.pop('pincode', '')
        sponsor_id = validated_data.pop('sponsor_id', '')
        category = validated_data.pop('category', 'consumer') or 'consumer'

        # Best-effort fallback: derive country/state/district (city) from pincode for Consumer, Employee and Sub-Franchise
        try:
            from locations.views import PINCODES_OFFLINE
        except Exception:
            PINCODES_OFFLINE = {}
        try:
            fallback_cats = {'consumer', 'employee', 'agency_sub_franchise'}
            pin_digits = ''.join(c for c in (pincode or '') if c.isdigit())
            if (not country or not state or not city) and pin_digits and len(pin_digits) == 6 and category in fallback_cats:
                meta = PINCODES_OFFLINE.get(pin_digits) or {}
                c_name = (meta.get('country') or '').strip()
                s_name = (meta.get('state') or '').strip()
                d_name = (meta.get('district') or '').strip()
                if c_name and not country:
                    country = Country.objects.filter(name__iexact=c_name).first() or Country.objects.create(name=c_name)
                if s_name and country and not state:
                    state = State.objects.filter(country=country, name__iexact=s_name).first() or State.objects.create(name=s_name, country=country)
                if d_name and state and not city:
                    city = City.objects.filter(state=state, name__iexact=d_name).first() or City.objects.create(name=d_name, state=state)
        except Exception:
            # fallback errors should not block registration
            pass

        # Region assignment inputs (write-only) already validated and cached on self.*
        # But pop from validated_data to avoid passing to create_user
        validated_data.pop('assign_states', None)
        validated_data.pop('selected_state', None)
        validated_data.pop('assign_districts', None)
        validated_data.pop('selected_district', None)
        validated_data.pop('assign_pincodes', None)
        validated_data.pop('selected_pincode', None)

        # Decide role if not explicitly provided
        role = validated_data.get('role')
        if not role:
            role = self._derive_role(category)

        # Pre-generate 6-digit id for this registration
        unique_id = CustomUser.generate_unique_id()

        # Build username based on category rules (ensure global uniqueness for non-consumer duplicates)
        username = self._build_unique_username(category, phone_digits, unique_id)

        # Determine who registered this account:
        # Prefer the sponsor user (by username) as the parent link; fall back to the authenticated actor.
        registered_by = getattr(self, '_sponsor_user', None)
        if not registered_by and request and request.user and request.user.is_authenticated:
            registered_by = request.user

        # Create user with registered_by set BEFORE first save so post_save can credit sponsor
        user = CustomUser(
            username=username,
            email=validated_data.get('email', ''),
            role=role,
            category=category,
            unique_id=unique_id,
            full_name=full_name,
            phone=phone_digits,
            pincode=pincode,
            country=country,
            state=state,
            city=city,
            registered_by=registered_by,
        )
        # Store upline's code in sponsor_id; keep user's own referral code in prefixed_id (allocated on save)
        try:
            if registered_by:
                user.sponsor_id = getattr(registered_by, "username", "") or sponsor_id
            else:
                user.sponsor_id = sponsor_id
        except Exception:
            user.sponsor_id = sponsor_id
        pwd_raw = validated_data.get('password')
        user.set_password(pwd_raw)
        try:
            user.last_password_encrypted = encrypt_string(pwd_raw)
        except Exception:
            user.last_password_encrypted = user.last_password_encrypted or None
        user.save()  # triggers post_save(created=True) with registered_by present

        # Post-create agency region handling
        if category in AGENCY_CATEGORIES:
            # Override fields based on selected inputs and create assignments accordingly
            if category == 'agency_state_coordinator':
                # Assign states
                for st in getattr(self, '_assign_states', []):
                    AgencyRegionAssignment.objects.create(
                        user=user, level='state', state=st
                    )
                # Populate country from first assigned state if not already set
                if not getattr(user, "country", None):
                    try:
                        st0 = next(iter(getattr(self, '_assign_states', [])))
                        if st0 and getattr(st0, "country", None):
                            user.country = st0.country
                    except Exception:
                        pass
                # Set a primary state for profile visibility if not already set
                if not getattr(user, "state", None):
                    try:
                        st0 = st0 if "st0" in locals() else next(iter(getattr(self, "_assign_states", [])))
                    except Exception:
                        st0 = None
                    if st0:
                        user.state = st0

            elif category == 'agency_state':
                sel_state = getattr(self, '_selected_state', None)
                if sel_state:
                    user.state = sel_state
                    AgencyRegionAssignment.objects.create(
                        user=user, level='state', state=sel_state
                    )
                    # Ensure country is populated from state
                    if not getattr(user, "country", None):
                        try:
                            user.country = getattr(sel_state, "country", None)
                        except Exception:
                            pass

            elif category == 'agency_district_coordinator':
                sel_state = getattr(self, '_selected_state', None)
                if sel_state:
                    user.state = sel_state
                for d in getattr(self, '_assign_districts', []):
                    AgencyRegionAssignment.objects.create(
                        user=user, level='district', state=sel_state, district=d
                    )
                # Populate city as first assigned district for profile (best-effort)
                try:
                    first_d = next(iter(getattr(self, '_assign_districts', [])))
                except Exception:
                    first_d = None
                if sel_state and first_d:
                    ci = City.objects.filter(state=sel_state, name__iexact=first_d).first() or City.objects.filter(state=sel_state, name__icontains=first_d).first()
                    if not ci:
                        try:
                            ci = City.objects.create(state=sel_state, name=first_d)
                        except Exception:
                            ci = None
                    if ci:
                        user.city = ci
                # Ensure country is populated from state
                if sel_state and not getattr(user, "country", None):
                    try:
                        user.country = getattr(sel_state, "country", None)
                    except Exception:
                        pass

            elif category == 'agency_district':
                sel_state = getattr(self, '_selected_state', None)
                sel_district = getattr(self, '_selected_district', None)
                if sel_state:
                    user.state = sel_state
                if sel_state and sel_district:
                    # District user should sponsor pincode coordinators => hold district assignment
                    AgencyRegionAssignment.objects.create(
                        user=user, level='district', state=sel_state, district=sel_district
                    )
                    # Populate city from selected district for profile (best-effort)
                    ci = City.objects.filter(state=sel_state, name__iexact=sel_district).first() or City.objects.filter(state=sel_state, name__icontains=sel_district).first()
                    if not ci:
                        try:
                            ci = City.objects.create(state=sel_state, name=sel_district)
                        except Exception:
                            ci = None
                    if ci:
                        user.city = ci
                # Ensure country is populated from state
                if sel_state and not getattr(user, "country", None):
                    try:
                        user.country = getattr(sel_state, "country", None)
                    except Exception:
                        pass

            elif category == 'agency_pincode_coordinator':
                sel_state = getattr(self, '_selected_state', None)
                sel_district = getattr(self, '_selected_district', None)
                if sel_state:
                    user.state = sel_state
                for pin in getattr(self, '_assign_pincodes', []):
                    AgencyRegionAssignment.objects.create(
                        user=user, level='pincode', state=sel_state, district=sel_district, pincode=pin
                    )
                # Populate city from selected district and set a representative pincode on profile (best-effort)
                if sel_state and sel_district:
                    ci = City.objects.filter(state=sel_state, name__iexact=sel_district).first() or City.objects.filter(state=sel_state, name__icontains=sel_district).first()
                    if not ci:
                        try:
                            ci = City.objects.create(state=sel_state, name=sel_district)
                        except Exception:
                            ci = None
                    if ci:
                        user.city = ci
                if not (getattr(user, "pincode", "") or ""):
                    try:
                        user.pincode = next(iter(getattr(self, '_assign_pincodes', [])))
                    except Exception:
                        pass
                # Ensure country is populated from state
                if sel_state and not getattr(user, "country", None):
                    try:
                        user.country = getattr(sel_state, "country", None)
                    except Exception:
                        pass

            elif category == 'agency_pincode':
                sel_pin = getattr(self, '_selected_pincode', None)
                if sel_pin:
                    user.pincode = sel_pin
                    # Pincode user should sponsor sub-franchise => hold pincode assignment
                    AgencyRegionAssignment.objects.create(
                        user=user, level='pincode', pincode=sel_pin
                    )
                # Best-effort: fill state/city/country from optional selected inputs (if provided)
                sel_state = getattr(self, '_selected_state', None)
                sel_district = getattr(self, '_selected_district', None)
                if sel_state and not getattr(user, "state", None):
                    user.state = sel_state
                if sel_state and not getattr(user, "country", None):
                    try:
                        user.country = getattr(sel_state, "country", None)
                    except Exception:
                        pass
                if sel_state and sel_district and not getattr(user, "city", None):
                    ci = City.objects.filter(state=sel_state, name__iexact=sel_district).first() or City.objects.filter(state=sel_state, name__icontains=sel_district).first()
                    if not ci:
                        try:
                            ci = City.objects.create(state=sel_state, name=sel_district)
                        except Exception:
                            ci = None
                    if ci:
                        user.city = ci

            elif category == 'agency_sub_franchise':
                sel_pin = getattr(self, '_selected_pincode', None)
                if sel_pin:
                    user.pincode = sel_pin
                # Best-effort: if UI provided state/district, reflect them in profile now
                sel_state = getattr(self, '_selected_state', None)
                sel_district = getattr(self, '_selected_district', None)
                if sel_state and not getattr(user, "state", None):
                    user.state = sel_state
                if sel_state and not getattr(user, "country", None):
                    try:
                        user.country = getattr(sel_state, "country", None)
                    except Exception:
                        pass
                if sel_state and sel_district and not getattr(user, "city", None):
                    ci = City.objects.filter(state=sel_state, name__iexact=sel_district).first() or City.objects.filter(state=sel_state, name__icontains=sel_district).first()
                    if not ci:
                        try:
                            ci = City.objects.create(state=sel_state, name=sel_district)
                        except Exception:
                            ci = None
                    if ci:
                        user.city = ci

        # Final geo backfill: if any geo fields are missing, derive from pincode (all categories incl. agency)
        try:
            pin_digits2 = ''.join(c for c in (getattr(user, 'pincode', '') or '') if c.isdigit())
            if pin_digits2 and len(pin_digits2) == 6:
                # Try offline cache first; lazy import if local var not present
                try:
                    meta2 = PINCODES_OFFLINE.get(pin_digits2)  # defined earlier in create(); fallback below if not
                except Exception:
                    try:
                        from locations.views import PINCODES_OFFLINE as _OFFLINE
                        meta2 = (_OFFLINE or {}).get(pin_digits2)
                    except Exception:
                        meta2 = None
                meta2 = meta2 or {}

                c_name = (meta2.get('country') or '').strip()
                s_name = (meta2.get('state') or '').strip()
                d_name = (meta2.get('district') or '').strip()

                # Online fallback via India Post if offline cache lacks data
                if not (c_name and s_name) or (not d_name):
                    try:
                        import requests
                        r = requests.get(f"https://api.postalpincode.in/pincode/{pin_digits2}", timeout=10)
                        if r.status_code == 200:
                            arr = r.json() or []
                            if isinstance(arr, list) and arr:
                                entry = arr[0] or {}
                                if entry.get("Status") == "Success":
                                    offices = entry.get("PostOffice") or []
                                    if offices:
                                        first = offices[0]
                                        c_name = c_name or (first.get("Country") or "").strip()
                                        s_name = s_name or (first.get("State") or "").strip()
                                        d_name = d_name or (first.get("District") or "").strip()
                    except Exception:
                        pass

                # Apply derived fields to the user
                if not getattr(user, "country", None) and c_name:
                    user.country = Country.objects.filter(name__iexact=c_name).first() or Country.objects.create(name=c_name)
                if not getattr(user, "state", None) and s_name and getattr(user, "country", None):
                    user.state = State.objects.filter(country=user.country, name__iexact=s_name).first() or State.objects.create(name=s_name, country=user.country)
                if not getattr(user, "city", None) and d_name and getattr(user, "state", None):
                    user.city = City.objects.filter(state=user.state, name__iexact=d_name).first() or City.objects.create(name=d_name, state=user.state)
        except Exception:
            pass

        user.save()
        return user


class PublicUserSerializer(serializers.ModelSerializer):
    country = serializers.StringRelatedField()
    state = serializers.StringRelatedField()
    city = serializers.StringRelatedField()
    registered_by_username = serializers.SerializerMethodField()
    avatar_url = serializers.SerializerMethodField()

    class Meta:
        model = CustomUser
        fields = [
            'id', 'username', 'unique_id', 'prefixed_id', 'prefix_code', 'email', 'full_name', 'phone',
            'country', 'state', 'city', 'pincode', 'address', 'sponsor_id',
            'category', 'role', 'registered_by', 'registered_by_username',
            'avatar_url',
            'date_joined', 'account_active', 'is_active'
        ]
        read_only_fields = fields

    def get_registered_by_username(self, obj):
        return getattr(obj.registered_by, 'username', None)

    def get_avatar_url(self, obj):
        try:
            f = getattr(obj, "avatar", None)
            if not f:
                return None
            # If the stored name is already an absolute URL (Cloudinary), return it verbatim
            try:
                name = getattr(f, "name", "") or ""
                if isinstance(name, str) and (name.startswith("http://") or name.startswith("https://")):
                    return name
            except Exception:
                pass

            # Best-effort migrate local avatar to Cloudinary on read if configured
            try:
                if os.environ.get("CLOUDINARY_URL"):
                    file_obj = None
                    try:
                        f.open("rb")
                        file_obj = getattr(f, "file", None) or f
                    except Exception:
                        file_obj = None
                    if file_obj is not None:
                        try:
                            from cloudinary import uploader as _clduploader  # type: ignore
                            try:
                                file_obj.seek(0)
                            except Exception:
                                pass
                            res = _clduploader.upload(
                                file_obj,
                                folder="uploads/profile",
                                resource_type="image",
                                invalidate=True,
                            )
                            url2 = (res or {}).get("secure_url") or (res or {}).get("url")
                            if url2:
                                obj.avatar.name = url2
                                obj.save(update_fields=["avatar"])
                                return url2
                        except Exception:
                            pass
            except Exception:
                pass

            # Else, fall back to storage-provided URL (relative under MEDIA_URL)
            url = getattr(f, "url", "") or ""
            if not url:
                return None

            # Fix corrupted MEDIA URL that percent-encodes a remote absolute URL (e.g., /media/https%3A/...)
            # Also handle single-slash forms like "https:/res.cloudinary.com" and normalize to "https://..."
            try:
                from urllib.parse import unquote
                import re
                decoded = unquote(url)
                m = re.search(r"(https?:/{1,2}\S+)", decoded)
                if m:
                    remote = m.group(1)
                    # Normalize single slash to double slash
                    remote = remote.replace("https:/", "https://").replace("http:/", "http://")
                    # Persist cleaned remote URL for future requests
                    try:
                        obj.avatar.name = remote
                        obj.save(update_fields=["avatar"])
                    except Exception:
                        pass
                    return remote
            except Exception:
                pass

            req = getattr(self, "context", {}).get("request", None)
            if req:
                try:
                    return req.build_absolute_uri(url)
                except Exception:
                    pass
            return url
        except Exception:
            return None

    def update(self, instance, validated_data):
        """
        Robust Cloudinary handling for avatar uploads:
        - Accept file from request.FILES['avatar'] or from validated_data['avatar'].
        - Prefer direct Cloudinary upload; on success, set absolute secure URL on instance.avatar.
        - If direct upload didn't occur (or failed), fall back to default update; then
          best-effort migrate the just-saved local file to Cloudinary and replace with secure URL.
        """
        request = getattr(self, "context", {}).get("request", None)

        # 1) Pick up an uploaded file from request.FILES or validated_data
        upload_file = None
        try:
            if request is not None and hasattr(request, "FILES"):
                upload_file = request.FILES.get("avatar") or None
        except Exception:
            upload_file = None
        # If not found in request.FILES, check validated_data (may contain InMemoryUploadedFile)
        vd_file = validated_data.get("avatar") if "avatar" in validated_data else None
        if upload_file is None and getattr(vd_file, "read", None):
            upload_file = vd_file

        did_cloud = False
        # 2) Direct Cloudinary upload path (when we have a file handle)
        if upload_file is not None:
            try:
                from cloudinary import uploader as _clduploader  # type: ignore
                # Ensure pointer at start
                try:
                    upload_file.seek(0)
                except Exception:
                    pass
                res = _clduploader.upload(
                    upload_file,
                    folder="uploads/profile",
                    resource_type="image",
                    invalidate=True,
                )
                url = (res or {}).get("secure_url") or (res or {}).get("url")
                if url:
                    try:
                        instance.avatar.name = url
                        instance.save(update_fields=["avatar"])
                        did_cloud = True
                        # Prevent default local save of the same file
                        validated_data.pop("avatar", None)
                    except Exception:
                        did_cloud = False
            except Exception:
                # Swallow and continue to default update; we'll try migrate-after-update
                did_cloud = False

        # 3) Proceed with normal updates for non-avatar fields
        inst = super().update(instance, validated_data)

        # 4) If Cloudinary is configured but upload didn't happen and avatar looks local, migrate it now
        try:
            import os
            cloud_enabled = bool(os.environ.get("CLOUDINARY_URL"))
        except Exception:
            cloud_enabled = False

        try:
            if cloud_enabled and not did_cloud:
                f = getattr(inst, "avatar", None)
                if f:
                    # If stored name is not already an absolute URL, try migrating
                    name = str(getattr(f, "name", "") or "")
                    is_abs = name.startswith("http://") or name.startswith("https://")
                    if not is_abs:
                        # Obtain a readable stream for the current file
                        file_obj = None
                        try:
                            # AvatarFile has .open() and .file
                            f.open("rb")
                            file_obj = getattr(f, "file", None) or f
                        except Exception:
                            file_obj = None
                        if file_obj is not None:
                            try:
                                from cloudinary import uploader as _clduploader2  # type: ignore
                                try:
                                    file_obj.seek(0)
                                except Exception:
                                    pass
                                res2 = _clduploader2.upload(
                                    file_obj,
                                    folder="uploads/profile",
                                    resource_type="image",
                                    invalidate=True,
                                )
                                url2 = (res2 or {}).get("secure_url") or (res2 or {}).get("url")
                                if url2:
                                    inst.avatar.name = url2
                                    inst.save(update_fields=["avatar"])
                            except Exception:
                                # best-effort only
                                pass
        except Exception:
            pass

        return inst


class ProfileMeSerializer(serializers.ModelSerializer):
    country = serializers.PrimaryKeyRelatedField(queryset=Country.objects.all(), required=False, allow_null=True)
    state = serializers.PrimaryKeyRelatedField(queryset=State.objects.all(), required=False, allow_null=True)
    city = serializers.PrimaryKeyRelatedField(queryset=City.objects.all(), required=False, allow_null=True)
    avatar = serializers.ImageField(required=False, allow_null=True, write_only=True)
    avatar_url = serializers.SerializerMethodField(read_only=True)
    age = serializers.IntegerField(required=False, allow_null=True, min_value=0, max_value=120)

    class Meta:
        model = CustomUser
        fields = [
            'id', 'username', 'email', 'full_name', 'phone', 'age',
            'country', 'state', 'city', 'pincode', 'address',
            'avatar', 'avatar_url',
        ]
        read_only_fields = ['id', 'username', 'avatar_url']

    def get_avatar_url(self, obj):
        try:
            f = getattr(obj, "avatar", None)
            if not f:
                return None
            # If the stored name is already an absolute URL (Cloudinary), return it verbatim
            try:
                name = getattr(f, "name", "") or ""
                if isinstance(name, str) and (name.startswith("http://") or name.startswith("https://")):
                    return name
            except Exception:
                pass

            # Best-effort migrate local avatar to Cloudinary on read if configured
            try:
                if os.environ.get("CLOUDINARY_URL"):
                    file_obj = None
                    try:
                        f.open("rb")
                        file_obj = getattr(f, "file", None) or f
                    except Exception:
                        file_obj = None
                    if file_obj is not None:
                        try:
                            from cloudinary import uploader as _clduploader  # type: ignore
                            try:
                                file_obj.seek(0)
                            except Exception:
                                pass
                            res = _clduploader.upload(
                                file_obj,
                                folder="uploads/profile",
                                resource_type="image",
                                invalidate=True,
                            )
                            url2 = (res or {}).get("secure_url") or (res or {}).get("url")
                            if url2:
                                obj.avatar.name = url2
                                obj.save(update_fields=["avatar"])
                                return url2
                        except Exception:
                            pass
            except Exception:
                pass

            # Else, fall back to storage-provided URL (relative under MEDIA_URL)
            url = getattr(f, "url", "") or ""
            if not url:
                return None

            # Fix corrupted MEDIA URL that percent-encodes a remote absolute URL (e.g., /media/https%3A/...)
            # Also handle single-slash forms like "https:/res.cloudinary.com" and normalize to "https://..."
            try:
                from urllib.parse import unquote
                import re
                decoded = unquote(url)
                m = re.search(r"(https?:/{1,2}\S+)", decoded)
                if m:
                    remote = m.group(1)
                    # Normalize single slash to double slash
                    remote = remote.replace("https:/", "https://").replace("http:/", "http://")
                    # Persist cleaned remote URL for future requests
                    try:
                        obj.avatar.name = remote
                        obj.save(update_fields=["avatar"])
                    except Exception:
                        pass
                    return remote
            except Exception:
                pass

            req = getattr(self, "context", {}).get("request", None)
            if req:
                try:
                    return req.build_absolute_uri(url)
                except Exception:
                    pass
            return url
        except Exception:
            return None

    def update(self, instance, validated_data):
        """
        Robust Cloudinary handling for avatar uploads:
        - Accept file from request.FILES['avatar'] or from validated_data['avatar'].
        - Prefer direct Cloudinary upload; on success, set absolute secure URL on instance.avatar.
        - If direct upload didn't occur (or failed), fall back to default update; then
          best-effort migrate the just-saved local file to Cloudinary and replace with secure URL.
        """
        request = getattr(self, "context", {}).get("request", None)

        # 1) Pick up an uploaded file from request.FILES or validated_data
        upload_file = None
        try:
            if request is not None and hasattr(request, "FILES"):
                upload_file = request.FILES.get("avatar") or None
        except Exception:
            upload_file = None
        # If not found in request.FILES, check validated_data (may contain InMemoryUploadedFile)
        vd_file = validated_data.get("avatar") if "avatar" in validated_data else None
        if upload_file is None and getattr(vd_file, "read", None):
            upload_file = vd_file

        did_cloud = False
        # 2) Direct Cloudinary upload path (when we have a file handle)
        if upload_file is not None:
            try:
                from cloudinary import uploader as _clduploader  # type: ignore
                # Ensure pointer at start
                try:
                    upload_file.seek(0)
                except Exception:
                    pass
                res = _clduploader.upload(
                    upload_file,
                    folder="uploads/profile",
                    resource_type="image",
                    invalidate=True,
                )
                url = (res or {}).get("secure_url") or (res or {}).get("url")
                if url:
                    try:
                        instance.avatar.name = url
                        instance.save(update_fields=["avatar"])
                        did_cloud = True
                        # Prevent default local save of the same file
                        validated_data.pop("avatar", None)
                    except Exception:
                        did_cloud = False
            except Exception:
                # Swallow and continue to default update; we'll try migrate-after-update
                did_cloud = False

        # 3) Proceed with normal updates for non-avatar fields
        inst = super().update(instance, validated_data)

        # 4) If Cloudinary is configured but upload didn't happen and avatar looks local, migrate it now
        try:
            import os
            cloud_enabled = bool(os.environ.get("CLOUDINARY_URL"))
        except Exception:
            cloud_enabled = False

        try:
            if cloud_enabled and not did_cloud:
                f = getattr(inst, "avatar", None)
                if f:
                    # If stored name is not already an absolute URL, try migrating
                    name = str(getattr(f, "name", "") or "")
                    is_abs = name.startswith("http://") or name.startswith("https://")
                    if not is_abs:
                        # Obtain a readable stream for the current file
                        file_obj = None
                        try:
                            # AvatarFile has .open() and .file
                            f.open("rb")
                            file_obj = getattr(f, "file", None) or f
                        except Exception:
                            file_obj = None
                        if file_obj is not None:
                            try:
                                from cloudinary import uploader as _clduploader2  # type: ignore
                                try:
                                    file_obj.seek(0)
                                except Exception:
                                    pass
                                res2 = _clduploader2.upload(
                                    file_obj,
                                    folder="uploads/profile",
                                    resource_type="image",
                                    invalidate=True,
                                )
                                url2 = (res2 or {}).get("secure_url") or (res2 or {}).get("url")
                                if url2:
                                    inst.avatar.name = url2
                                    inst.save(update_fields=["avatar"])
                            except Exception:
                                # best-effort only
                                pass
        except Exception:
            pass

        return inst

class UserNomineeSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserNominee
        fields = ["id", "name", "relationship", "phone", "share_percent", "created_at", "updated_at"]
        read_only_fields = ["id", "created_at", "updated_at"]

class UserKYCSerializer(serializers.ModelSerializer):
    can_submit_kyc = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = UserKYC
        fields = [
            "bank_name",
            "bank_account_number",
            "ifsc_code",
            "aadhaar_digilocker_url",
            "verified",
            "verified_at",
            "kyc_reopen_allowed",
            "can_submit_kyc",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["verified", "verified_at", "kyc_reopen_allowed", "can_submit_kyc", "created_at", "updated_at"]

    def get_can_submit_kyc(self, obj):
        try:
            return (not bool(getattr(obj, "verified", False))) or bool(getattr(obj, "kyc_reopen_allowed", False))
        except Exception:
            return True

    def update(self, instance, validated_data):
        """
        Guard: Once KYC is verified, user cannot modify unless kyc_reopen_allowed=True.
        On any successful edit, reset verified=False and consume the reopen allowance.
        """
        # If already verified and not reopened via support, block update
        if bool(getattr(instance, "verified", False)) and not bool(getattr(instance, "kyc_reopen_allowed", False)):
            raise serializers.ValidationError({
                "detail": "KYC already verified. Please create a Support ticket to request re-verification.",
                "code": "KYC_LOCKED"
            })

        # Perform updates
        for f in ("bank_name", "bank_account_number", "ifsc_code", "aadhaar_digilocker_url"):
            if f in validated_data:
                setattr(instance, f, validated_data[f])

        # If previously verified, mark unverified after change
        if bool(getattr(instance, "verified", False)):
            instance.verified = False
            instance.verified_at = None
            instance.verified_by = None

        # Consume reopen allowance after any edit
        instance.kyc_reopen_allowed = False
        instance.save()
        return instance


class SupportTicketMessageSerializer(serializers.ModelSerializer):
    author_username = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = SupportTicketMessage
        fields = ["id", "author", "author_username", "message", "created_at"]
        read_only_fields = ["id", "author_username", "created_at", "author"]

    def get_author_username(self, obj):
        try:
            return getattr(obj.author, "username", None)
        except Exception:
            return None


class SupportTicketSerializer(serializers.ModelSerializer):
    messages = SupportTicketMessageSerializer(many=True, read_only=True)
    user_username = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = SupportTicket
        fields = [
            "id",
            "user",
            "user_username",
            "type",
            "subject",
            "message",
            "status",
            "admin_assignee",
            "resolution_note",
            "created_at",
            "updated_at",
            "messages",
        ]
        read_only_fields = ["status", "user", "admin_assignee", "resolution_note", "created_at", "updated_at", "messages", "user_username"]

    def get_user_username(self, obj):
        try:
            return getattr(obj.user, "username", None)
        except Exception:
            return None

    def validate(self, attrs):
        # Enforce only one open/in_progress KYC_REVERIFY per user
        req = self.context.get("request")
        user = getattr(req, "user", None) if req else None
        t = (attrs.get("type") or "").strip()
        if user and t == "KYC_REVERIFY":
            exists = SupportTicket.objects.filter(
                user=user, type="KYC_REVERIFY", status__in=["open", "in_progress"]
            ).exists()
            if exists:
                raise serializers.ValidationError({"detail": "An open KYC re-verification request already exists."})
        return attrs

    def create(self, validated_data):
        req = self.context.get("request")
        user = getattr(req, "user", None) if req else None
        if user and not validated_data.get("user"):
            validated_data["user"] = user
        return super().create(validated_data)


class WithdrawalRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = WithdrawalRequest
        fields = [
            "id",
            "amount",
            "method",
            "upi_id",
            "bank_name",
            "bank_account_number",
            "ifsc_code",
            "note",
            "status",
            "requested_at",
            "decided_at",
            "payout_ref",
        ]
        read_only_fields = ["status", "requested_at", "decided_at", "payout_ref"]

    def validate(self, attrs):
        from decimal import Decimal
        amt = attrs.get("amount")
        try:
            if amt is None or Decimal(amt) <= 0:
                raise serializers.ValidationError({"amount": "Amount must be greater than 0."})
        except Exception:
            raise serializers.ValidationError({"amount": "Invalid amount."})

        # Only bank withdrawals are supported
        method = (attrs.get("method") or "bank").lower()
        if method != "bank":
            raise serializers.ValidationError({"method": "Only bank withdrawals are supported."})
        attrs["method"] = "bank"
        # Bank details may be filled from KYC in create()
        return attrs

    def create(self, validated_data):
        """
        Create a withdrawal request with the following business rules:
        - KYC must be verified
        - Withdrawable balance must be >= ₹500 (enable threshold)
        - Per request cap is ₹750 (or current withdrawable balance, whichever is lower)
        - Only one request allowed within each Sunday 6:00 PM–11:59 PM (IST) window
        - Requests can only be made on Sunday between 18:00 and 23:59 IST
        """
        from decimal import Decimal
        from datetime import datetime, time, timedelta, timezone as dt_timezone
        from zoneinfo import ZoneInfo
        from django.utils import timezone
        from .models import WithdrawalRequest, Wallet

        request = self.context.get("request")
        user = getattr(request, "user", None)
        if not user or not user.is_authenticated:
            raise serializers.ValidationError({"detail": "Authentication required."})

        # Normalize method + bank fields (will hydrate from KYC later if needed)
        method = (validated_data.get("method") or "bank").lower()
        bank_name = (validated_data.get("bank_name") or "").strip()
        bank_acc = (validated_data.get("bank_account_number") or "").strip()
        ifsc = (validated_data.get("ifsc_code") or "").strip()

        # Amount checks (will also compare against wallet balance below)
        try:
            amount = Decimal(validated_data.get("amount"))
        except Exception:
            raise serializers.ValidationError({"amount": "Invalid amount."})
        if amount <= 0:
            raise serializers.ValidationError({"amount": "Amount must be greater than 0."})

        # KYC must be verified
        try:
            kyc = getattr(user, "kyc", None)
        except Exception:
            kyc = None
        if not kyc or not getattr(kyc, "verified", False):
            raise serializers.ValidationError({"detail": "KYC verification required to request withdrawal.", "code": "KYC_REQUIRED"})

        # Wallet balance must be >= 500 and >= requested amount
        w = Wallet.get_or_create_for_user(user)
        try:
            wd = Decimal(w.withdrawable_balance or 0)
        except Exception:
            wd = Decimal("0")
        if wd < Decimal("500"):
            short = (Decimal("500") - wd)
            raise serializers.ValidationError({
                "detail": "Minimum withdrawable balance ₹500 required to enable withdrawals.",
                "code": "INSUFFICIENT_MIN_BALANCE",
                "short_by": str(short.quantize(Decimal("0.01"))),
            })
        per_tx_cap = Decimal("750.00")
        max_now = wd if wd < per_tx_cap else per_tx_cap
        if amount > max_now:
            raise serializers.ValidationError({
                "detail": f"Max per request is ₹{per_tx_cap.quantize(Decimal('0.00'))}. Available to withdraw now: ₹{max_now.quantize(Decimal('0.00'))}.",
                "code": "AMOUNT_EXCEEDS_CAP_OR_BALANCE",
            })

        # Enforce Wednesday 7PM-9PM IST window
        IST = ZoneInfo("Asia/Kolkata")
        now_local = timezone.now().astimezone(IST)

        # Compute this week's Sunday date (Mon=0..Sun=6)
        days_since_sun = (now_local.weekday() + 1) % 7
        sun_date = now_local.date() - timedelta(days=days_since_sun)

        window_start_local = datetime.combine(sun_date, time(18, 0), IST)  # 6:00 PM IST
        window_end_local = datetime.combine(sun_date, time(23, 59, 59), IST)  # 11:59 PM IST

        # Determine current/next window info
        if now_local < window_start_local:
            next_window_start_local = window_start_local
        elif now_local > window_end_local:
            next_window_start_local = datetime.combine(sun_date + timedelta(days=7), time(18, 0), IST)
        else:
            next_window_start_local = window_start_local

        if not (window_start_local <= now_local <= window_end_local):
            raise serializers.ValidationError({
                "detail": "Withdrawals can be requested only on Sunday between 6:00 PM and 11:59 PM (IST).",
                "code": "WINDOW_CLOSED",
                "next_window_at": next_window_start_local.astimezone(dt_timezone.utc).isoformat(),
                "next_window_at_ist": next_window_start_local.isoformat(),
            })

        # Limit to 1 request per weekly window (this Sunday 18:00–23:59 IST)
        window_start_utc = window_start_local.astimezone(dt_timezone.utc)
        window_end_utc = window_end_local.astimezone(dt_timezone.utc)
        exists_in_window = WithdrawalRequest.objects.filter(
            user=user,
            requested_at__gte=window_start_utc,
            requested_at__lte=window_end_utc,
        ).exclude(status="rejected").exists()
        if exists_in_window:
            next_window_start_local = datetime.combine(sun_date + timedelta(days=7), time(18, 0), IST)
            raise serializers.ValidationError({
                "detail": "Only one withdrawal request is allowed per weekly window.",
                "code": "WEEKLY_LIMIT_REACHED",
                "next_window_at": next_window_start_local.astimezone(dt_timezone.utc).isoformat(),
                "next_window_at_ist": next_window_start_local.isoformat(),
            })

        # If bank method and missing fields, hydrate from KYC
        if method == "bank" and (not bank_acc or not ifsc):
            try:
                if kyc:
                    bank_name = bank_name or (kyc.bank_name or "")
                    bank_acc = bank_acc or (kyc.bank_account_number or "")
                    ifsc = ifsc or (kyc.ifsc_code or "")
            except Exception:
                pass
            if not bank_acc or not ifsc:
                raise serializers.ValidationError({"detail": "Bank account number and IFSC are required for bank withdrawals."})

        # Create pending withdrawal request (no immediate debit; debit on admin approval)
        wr = WithdrawalRequest.objects.create(
            user=user,
            amount=amount,
            method="bank",
            upi_id=(validated_data.get("upi_id") or "").strip(),
            bank_name=bank_name,
            bank_account_number=bank_acc,
            ifsc_code=ifsc,
            note=(validated_data.get("note") or ""),
        )
        return wr
